package p1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ValidateAdmin")
public class ValidateAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String name=request.getParameter("t1");
		String pwd=request.getParameter("t2");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			out.println("Driver class loaded");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CollegeManagement","root","tiger");
			out.println("Connection established");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from admin where username='"+name+"' AND password='"+pwd+"'");
			if(rs.next())
				response.sendRedirect("work.html");
			
			else
				out.println("Incorrect Username and password");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			out.println("Error");
		}
	}

}
