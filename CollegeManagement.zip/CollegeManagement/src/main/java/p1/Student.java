package p1;
import java.io.PrintWriter;
import java.sql.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Student
 */
@WebServlet("/Student")
public class Student extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Student() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String operation=request.getParameter("operation");
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/CollegeManagement","root","tiger");
        	switch(operation) {
        	case "create":
        		PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?)");
    			int sid=Integer.parseInt(request.getParameter("t1"));
    			String name=request.getParameter("n");
    			int m1=Integer.parseInt(request.getParameter("m1"));
    			int m2=Integer.parseInt(request.getParameter("m2"));
    			int m3=Integer.parseInt(request.getParameter("m3"));
    			int m4=Integer.parseInt(request.getParameter("m4"));
    			int m5=Integer.parseInt(request.getParameter("m5"));
    			int m6=Integer.parseInt(request.getParameter("m6"));
    			String pwd=request.getParameter("p");
    			ps.setInt(1, sid);
    			ps.setString(2, name);
    			ps.setInt(3, m1);
    			ps.setInt(4, m2);
    			ps.setInt(5, m3);
    			ps.setInt(6, m4);
    			ps.setInt(7, m5);
    			ps.setInt(8, m6);
    			ps.setString(9, pwd);
    			ps.execute();
    			out.println("Inserted successfully");
    			break;
        	case "update":
        		int sid1=Integer.parseInt(request.getParameter("t1"));
        		String cl=request.getParameter("n");
        		int um=Integer.parseInt(request.getParameter("m"));
        		PreparedStatement ps1 = con.prepareStatement("UPDATE student SET " + cl + "=? WHERE sid=?");
        		ps1.setInt(1, um);
        		ps1.setInt(2, sid1);
        		ps1.executeUpdate();
        		out.println("updated successfully");
        		break;
        	case "delete":
        		int sid2=Integer.parseInt(request.getParameter("t1"));
        		Statement st=con.createStatement();
        		ResultSet rs=st.executeQuery("Select * from student where sid="+sid2);
        		if(rs.next()) {
        			st.executeUpdate("delete from student where sid="+sid2);
        			out.println("deleted successfully");
        		}
        		else {
        			out.println("enter correct id");
        		}
        		break;
        	}
	}
        catch(Exception e) {
        	out.println(e);
        }
	}
}
