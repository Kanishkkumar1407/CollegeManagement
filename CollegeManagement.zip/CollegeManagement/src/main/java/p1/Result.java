package p1;
import java.io.PrintWriter;
import java.sql.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Result
 */
@WebServlet("/Result")
public class Result extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     * .3
     * 
     * 
     */
    public Result() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/CollegeManagement","root","tiger");
        	Statement st1=con.createStatement();
        	int sid=Integer.parseInt(request.getParameter("s1"));
			String pwd=request.getParameter("s3");
			ResultSet rs1=st1.executeQuery("select * from student where sid="+sid);
			int m[]=new int[6];
			String g[]=new String[6];
			while(rs1.next()) {
				for(int i=0;i<6;i++) {
					m[i]=rs1.getInt(i+3);
					if(m[i]>=90) {
						g[i]="O";
					}
					if(m[i]<90 && m[i]>=80) {
						g[i]="A";
					}
					if(m[i]>=70 && m[i]<80) {
						g[i]="B";
					}
					if(m[i]>=60 && m[i]<70) {
						g[i]="C";
					}
					if(m[i]>=50 && m[i]<60) {
						g[i]="D";
					}
					if(m[i]<50) {
						g[i]="F";
					}
				}
				String grade;
				if(g[0]=="F" || g[1]=="F" || g[2]=="F" || g[3]=="F" || g[4]=="F" || g[5]=="F") {
					grade="fail";
				}
				else {
					grade="pass";
				}
				out.println("<html><body align='center' bgcolor='pink'>");
        		out.println("Student id is "+rs1.getInt(1)+"<br>");
        		out.println("Student name is "+rs1.getString(2)+"<br>");
        		out.println("<table border='1' align='center'>");
        		out.println("<tr><th>Subject Name</th><th>Marks obtained</th><th>Grade</th></tr>");
        		out.println("<tr>");
        		out.println("<td>"+"C Language"+"</td>");
        		out.println("<td>"+m[0]+"</td>");
        		out.println("<td>"+g[0]+"</td>");
        		out.println("</tr>");
        		out.println("<tr>");
        		out.println("<td>"+"Python"+"</td>");
        		out.println("<td>"+m[1]+"</td>");
        		out.println("<td>"+g[1]+"</td>");
        		out.println("</tr>");
        		out.println("<tr>");
        		out.println("<td>"+"Maths"+"</td>");
        		out.println("<td>"+m[2]+"</td>");
        		out.println("<td>"+g[2]+"</td>");
        		out.println("</tr>");
        		out.println("<tr>");
        		out.println("<td>"+"Java"+"</td>");
        		out.println("<td>"+m[3]+"</td>");
        		out.println("<td>"+g[3]+"</td>");
        		out.println("</tr>");
        		out.println("<tr>");
        		out.println("<td>"+"DBMS"+"</td>");
        		out.println("<td>"+m[4]+"</td>");
        		out.println("<td>"+g[4]+"</td>");
        		out.println("</tr>");
        		out.println("<tr>");
        		out.println("<td>"+"DAA"+"</td>");
        		out.println("<td>"+m[5]+"</td>");
        		out.println("<td>"+g[5]+"</td>");
        		out.println("</tr>");
        		out.println("</table>");
        		out.println("grade="+grade);
        		out.println("</body></html>");
			}
		}
		catch(Exception e) {
			out.println(e);
		}
	}

}
